<section class="signup-cta-section">
    <div class="container">
        <div class="cta-content">
            <h2 class="section-title">¡Únete a la comunidad!</h2>
            <p class="section-text">Conecta con coleccionistas, gestiona tu colección y participa en eventos exclusivos.</p>
            
            <div class="action-links">
                <a href="auth/signup.php" class="hero-btn">Crear Cuenta</a>
            </div>
        </div>
    </div>
</section>