<div class="mobile-overlay" id="mobileOverlay">
    <div class="container">
        <div class="row">
            <div class="col left">
                <!-- Empty column -->
            </div>
            <div class="col right">
                <!-- Close Icon -->
                <div class="close-icon">
                    <i class="bi bi-x-lg"></i>
                </div>
            </div>
        </div>
        <!-- Mobile Menu Content -->
        <div class="mobile-menu-content">
            <ul class="mobile-nav-list">
                <li class="mobile-nav-item"><a href="auth/login.php" class="mobile-nav-link">Inicio</a></li>
                <li class="mobile-nav-item"><a href="#" class="mobile-nav-link">Red Social</a></li>
                <li class="mobile-nav-item"><a href="#" class="mobile-nav-link">Marketplace</a></li>
                <li class="mobile-nav-item"><a href="#" class="mobile-nav-link">Eventos</a></li>
                <li class="mobile-nav-item"><a href="#" class="mobile-nav-link">#Colector</a></li>
                <li class="mobile-nav-item"><a href="auth/signup.php" class="mobile-btn-empieza">Empieza Ya!</a></li>
            </ul>
        </div>
    </div>
</div>